<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/riad/Desktop/integrum-dev/integrum_case_management/resources/views/Admin/dashboard.blade.php ENDPATH**/ ?>