<!-- SCRIPTS -->
  <!-- Global Required Scripts Start -->
  <script src="<?php echo e(asset('/admin/assets/js/jquery-3.3.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/admin/assets/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/assets/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/admin/assets/js/perfect-scrollbar.js')); ?>"> </script>
  <script src="<?php echo e(asset('/admin/assets/js/jquery-ui.min.js')); ?>"> </script>
  <!-- Global Required Scripts End -->

  <!-- Page Specific Scripts Start -->
  <script src="<?php echo e(asset('/admin/assets/js/moment.js')); ?>"> </script>
  <script src="<?php echo e(asset('/admin/assets/js/jquery.webticker.min.js')); ?>"> </script>
  <script src="<?php echo e(asset('/admin/assets/js/Chart.bundle.min.js')); ?>"> </script>
  <script src="<?php echo e(asset('/admin/assets/js/Chart.Financial.js')); ?>"> </script>
  <script src="<?php echo e(asset('/admin/assets/js/table-line.js')); ?>"> </script>
  <script src="<?php echo e(asset('/admin/assets/js/index-chart.js')); ?>"> </script>

  <script src="<?php echo e(asset('/admin/assets/js/d3.v3.min.js')); ?>"> </script>
  <script src="<?php echo e(asset('/admin/assets/js/topojson.v1.min.js')); ?>"> </script>
  <script src="<?php echo e(asset('/admin/assets/js/datamaps.all.min.js')); ?>"> </script>
  <script src="<?php echo e(asset('/admin/assets/js/index-map.js')); ?>"> </script>

  <!-- Page Specific Scripts Start -->
  <script src="<?php echo e(asset('/admin/assets/js/slick.min.js')); ?>"> </script>
  <script src="<?php echo e(asset('/admin/assets/js/product-line.js')); ?>"> </script>
  <script src="<?php echo e(asset('/admin/assets/js/datatables.min.js')); ?>"> </script>
  <script src="<?php echo e(asset('/admin/assets/js/data-tables.js')); ?>"> </script>




  <!-- Page Specific Scripts End -->

  <!-- Cannadash core JavaScript -->
  <script src="<?php echo e(asset('/admin/assets/js/framework.js')); ?>"></script>

  <!-- Settings -->
  <script src="<?php echo e(asset('/admin/assets/js/settings.js')); ?>"></script><?php /**PATH /home/riad/Desktop/integrum-dev/integrum_case_management/resources/views/Admin/includes/script.blade.php ENDPATH**/ ?>