<?php $__env->startSection('content'); ?>
    <div class="ms-content-wrapper">
        <form action="<?php echo e(url('/case-update/' . $case[0]->id)); ?>" method="post" class="needs-validation" novalidate="">
            <div class="row">

                <div class="col-xl-6 col-md-12">
                    <div class="ms-panel">
                        <div class="ms-panel-header">
                            <h6>Edit Case</h6>
                        </div>
                        <div class="ms-panel-body">

                            <?php echo csrf_field(); ?>

                            <div class="form-row">
                                <div class="col-md-12 mb-3">
                                    <label for="validationCustom03">Case Title</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" value="<?php echo e($case[0]->case_title); ?>"
                                            id="validationCustom03" name="case_title" required="">
                                        <div class="invalid-feedback">
                                            Please provide a valid email.
                                        </div>
                                        <?php $__errorArgs = ['case_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span style="color: red" class="backend-error"> <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                        </div>






                        <div class="form-row">
                            <div class="col-md-12 mb-3">
                                <label for="validationCustom03">Case Description</label>
                                <div class="input-group">
                                    <textarea class="form-control" name="description" id="validationCustom03"><?php echo e($case[0]->description); ?></textarea>
                                    <div class="invalid-feedback">
                                        Please provide a valid Language.
                                    </div>
                                </div>
                            </div>
                        </div>






                        <div class="col-md-6 mb-3">
                            <label for="validationCustom22">Assigne A Employee</label>
                            <div class="input-group">
                                <select class="form-control" id="validationCustom22" name="employee" required="">
                                    <option value="">Select an Employee</option>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"
                                            <?php echo e($item->id == $case[0]->employee_id ? 'selected' : ''); ?>>
                                            <?php echo e($item->first_name); ?>

                                            <?php echo e($item->last_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="invalid-feedback">
                                    Please select a Country.
                                </div>
                            </div>
                        </div>









                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="ms-panel ms-panel-fh">
                    <div class="ms-panel-header">
                        <h6>hlaðið upp skrám</h6>
                    </div>

                    <?php
                        $files = DB::table('file_uploads')
                            ->where('user_id', $case[0]->user_id)
                            ->get();
                    ?>

                    <div class="ms-panel-body">
                        <div class="p-0">
                            <h2 class="mb-4">Files</h2>
                            <div class="card">
                                <div class="card-body p-0">
                                    <div id="files" class="row">
                                        

                                    </div>
                                </div>
                                <a id="load_more" onclick="LoadMore()" style="color:white"
                                    class="btn btn-primary mt-4 d-block w-100" type="submit">Load More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

           

            <div class="col-xl-6 col-md-12">
                <table class="table table-striped thead-primary w-100">
                    <thead>
                        <tr>

                            <th scope="col">Case Files</th>
                            <th scope="col">Approved By</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $case_files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td>
                                    <div class="form-group form-check">
                                        <input type="checkbox" onclick="updateCaseFiles(this)" value=<?php echo e($key); ?>

                                            <?php echo e($item == 'yes' ? 'checked' : ''); ?> class="form-check-input"
                                            id="exampleCheck1">
                                        <input type="hidden" id="approved_by" value="<?php echo e(Auth::user()->id); ?>">
                                        <input type="hidden" id="user_id" value="<?php echo e($case[0]->user_id); ?>">
                                        <input type="hidden" id="case_id" value="<?php echo e($case[0]->id); ?>">
                                        <label class="form-check-label" for="exampleCheck1"><?php echo e($key); ?></label>
                                    </div>

                                </td>
                                <td><?php echo e($approves[$key]); ?></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <div class="col-xl-12 col-md-12">
                <div class="ms-panel ms-panel-fh">
                  <div class="ms-panel-header">
                    <h6>Tímalína</h6>
                  </div>
                  <div class="ms-panel-body">
                      <div class="time-line">
                          <ul>

                            <?php $__currentLoopData = $timelines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <li>
                                  <span class="time-line_heading"><?php echo e($key); ?></span>
                                  <span class="time-arrow"><img src="<?php echo e(asset('/admin/assets/img/custom/step-arrow.svg')); ?>" alt=""/></span>
                                  <input type="text" value="<?php echo e($item); ?>" name="date[]"  class="form-control">
                                  <input type="hidden" value="<?php echo e($key); ?>" name="title[]"  class="form-control">
                                  
                              </li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                          </ul>
                      </div>
                  </div>
                </div>
              </div>

            <button class="btn btn-primary mt-4 d-block w-100" type="submit">Update</button>

    </div>

    </form>

    </div>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script>
        function updateCaseFiles(el) {
            let caseFileName = el.value;
            let caseId = document.getElementById('case_id').value;
            let approved_by = document.getElementById('approved_by').value;

            const formData = {
                case_file: caseFileName,
                case_id: caseId,
                approved_by: approved_by,
                status: el.checked
            }

            axios.post(`/api/update-case-file-list/${caseId}`, formData)
                .then((response => {
                    console.log(response.data);
                }))
                .catch(error => {
                    console.log(error.response);
                })

        }

        let files = new Array();

        async function fetchFiles(page) {
            let html = ''
            let user_id = document.getElementById('user_id').value;
            let response = await axios.get(`/api/case-files/${page}/${user_id}`);
            let url = 'http://127.0.0.1:8000/'

            response.data.uploaded_files.map((item) => {
                files.push(item)
                if (files.length === response.data.total) {
                    document.getElementById('load_more').classList.remove('display');
                    document.getElementById('load_more').classList.add('hidden');
                } else {
                    document.getElementById('load_more').classList.remove('hidden');
                    document.getElementById('load_more').classList.add('display');
                }
            })
            files.map((item) => {
                html += '<div class="col-md-4">';
                if (item.file_extention == 'jpg' || item.file_extention == 'png') {
                    html += '<img style="width:70px;" src=' + url + item.file + '>';
                } else {
                    html += '<img style="width:70px;" src=' + url + 'admin/assets/img/file-icon.png' + '>';
                }

                html += '<a href=' + url + item.file +
                    ' style="text-align: center;margin-left:12px" download>' + item.title + '</a>'
                html += '</div>';
                document.getElementById('files').innerHTML = html;
            })


        }
        let count = 0;

        function LoadMore() {
            count++;

            fetchFiles(count);

        }
        fetchFiles(0);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/riad/Desktop/integrum-dev/integrum_case_management/resources/views/Admin/Case-management/edit.blade.php ENDPATH**/ ?>