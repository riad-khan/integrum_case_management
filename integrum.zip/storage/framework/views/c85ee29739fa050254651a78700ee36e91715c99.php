
    <div class="col-xl-3 col-md-12">
        <div class="ms-panel ms-panel-fh">
          <div class="ms-panel-body">
            <h2 class="section-title">Persónuupplýsingar</h2>


            
            <table class="table ms-profile-information">
              <tbody>
                <tr>
                  <th scope="row">Full Name</th>
                  <td><?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?></td>
                </tr>
                <tr>
                  <th scope="row">Birthday</th>
                  <td><?php echo e(Auth::user()->date_of_birth); ?></td>
                </tr>
                <tr>
                  <th scope="row">Language</th>
                  <td><?php echo e(Auth::user()->language); ?></td>
                </tr>
                <tr>
                  <th scope="row">Website</th>
                  <td><?php echo e(Auth::user()->website); ?></td>
                </tr>
                <tr>
                  <th scope="row">Phone Number</th>
                  <td><?php echo e(Auth::user()->phone_number); ?></td>
                </tr>
                <tr>
                  <th scope="row">Email Address</th>
                  <td><?php echo e(Auth::user()->email); ?></td>
                </tr>
                <tr>
                  <th scope="row">Location</th>
                  <td><?php echo e(Auth::user()->location); ?></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

<?php /**PATH /home/riad/Desktop/integrum-dev/integrum_case_management/resources/views/livewire/admin/user/components/user-details.blade.php ENDPATH**/ ?>