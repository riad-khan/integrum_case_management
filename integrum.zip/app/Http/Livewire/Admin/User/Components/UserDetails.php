<?php

namespace App\Http\Livewire\Admin\User\Components;

use Livewire\Component;

class UserDetails extends Component
{
    public function render()
    {
        return view('livewire.admin.user.components.user-details');
    }
}
