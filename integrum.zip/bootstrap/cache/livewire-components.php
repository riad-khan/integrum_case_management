<?php return array (
  'admin.user.components.user-details' => 'App\\Http\\Livewire\\Admin\\User\\Components\\UserDetails',
);